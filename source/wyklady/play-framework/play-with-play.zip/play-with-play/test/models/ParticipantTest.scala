package models

import play.api.test.FakeApplication
import org.specs2.mutable._
import play.api.test._
import play.api.test.Helpers._

class ParticipantTest extends Specification {

  "Participant model" should {
    
    "save new participant" in {
      running(FakeApplication(additionalConfiguration = inMemoryDatabase())) {
        //given
        val participant = Participant("Tomek", "tomek@onet.pl", 1)
        
        //when
        Participant.save(participant)
        val participants = Participant.allParticipants(1)
        
        //then
        participants.size must beEqualTo(1)
        participants.forall(_.name.equals("Tomek")) must beTrue
      }
    }
    
  }
}
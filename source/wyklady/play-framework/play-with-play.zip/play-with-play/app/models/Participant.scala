package models

import play.api.Play.current
import play.api.db._
import anorm._
import anorm.SqlParser._
import play.api.Logger

case class Participant(name: String, email: String, lectureId: Int)

object Participant {
  
  // ~parser
  
  def simple: RowParser[Participant] = {
    str("participant.name") ~
    str("participant.email") ~
    int("participant.lecture_id") map {
      case name ~ email ~ lectureId => Participant(name, email, lectureId)
    }
  }
  
  def save(participant: Participant) {
    val sql = """
      insert into participant(name, email, lecture_id) 
      values({name}, {email}, {lectureId})
      """
    Logger("sql").debug(sql)
    DB.withConnection( implicit connection =>
      SQL(sql).on(
        'name -> participant.name,
        'email -> participant.email,
        'lectureId -> participant.lectureId
      ).executeInsert()
    )
  }
  
  def allParticipants( lectureId: Int) = {
    val sql = """
      select * from participant 
      where lecture_id = {lectureId}
      """
    Logger("sql").debug(sql)
    DB.withConnection(implicit connection =>
      SQL(sql)
      	.on('lectureId -> lectureId)
      	.as(simple *)
    )
  }
  
}
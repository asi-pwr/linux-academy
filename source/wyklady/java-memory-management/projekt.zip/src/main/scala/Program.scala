import scala.annotation.tailrec
import scala.collection.mutable
import scala.concurrent._
import ExecutionContext.Implicits.global

/**
 * Created by Bartosz Jankiewicz on 12/17/13.
 */
object Program extends App {

  val rate = args(0).toInt
  val lifeTime = args(1).toLong * 1000l
  val size = args(2).toInt

  Console.println(s"Allocating $size bytes objects at rate of $rate per second which are will live for $lifeTime")

  val queue = mutable.Queue[Data]()
  var rateCounter = rate
  var cycleStart = System.currentTimeMillis()


  val f: Future[String] = Future {
    def dropOld() {
      queue.takeWhile(data => {
        System.currentTimeMillis() - data.created > lifeTime
      })
      dropOld()
    }
    dropOld()
    "Done"
  }

  @tailrec
  def allocate() {
    //reset counter every second
    if( System.currentTimeMillis() - cycleStart > 1000) {
      rateCounter = rate
      cycleStart = System.currentTimeMillis()
    }

    //allocate up to given amount of objects every second
    if( rateCounter > 0) {
      val obj = Data(new Array[Byte](size), System.currentTimeMillis())
      queue.enqueue(obj)
      rateCounter = rateCounter - 1
    }

    //loop
    allocate()
  }


  allocate()
}

case class Data(payload: Array[Byte], created: Long)

$(function() {

    setInterval(function() {
        $.get('http://mewp.pl/remote/', function(a, b, data) {
            $.deck('go', parseInt(data.responseText)-1);
        });
    }, 100);

});
